#include <stdio.h>

void main() {
	FILE *f = fopen("input.txt", "r");
	if(f == NULL) {
		printf("File not found!\n");
		return;
	}
	int upper = 0, lower = 0, digit = 0, special = 0;
	
	char c = fgetc(f);
	while(c != '\0' && c != EOF) {
		if(c >= 'A' && c <= 'Z') upper++;
		else if(c >= 'a' && c <= 'z') lower++;
		else if(c >= '0' && c <= '9') digit++;
		else if(c != '\n' && c != ' ') special++;
		
		c = fgetc(f);
	}
	fclose(f);
	
	f = fopen("output.txt", "w+");
	fprintf(f, "No. of upper case alphabets: %d\n", upper);
	fprintf(f, "No. of lower case alphabets: %d\n", lower);
	fprintf(f, "Numbers: %d\n", digit);
	fprintf(f, "Special characters: %d\n", special);
	fclose(f);
}
